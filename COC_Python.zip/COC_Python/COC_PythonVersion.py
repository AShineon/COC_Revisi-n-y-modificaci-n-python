import numpy as np
from scipy.cluster.hierarchy import linkage, inconsistent, fcluster
import math


contador = 0

def evaluateF(X, F_index):
    global contador
    # Se simula el acceso a la función objetivo.
    contador += X.shape[0]
    # Reemplaza con la lógica real de tu función objetivo F_index
    if X.ndim == 1:
        X = X.reshape(1, -1)
    return np.sum(X**2, axis=1) # Placeholder: Ejemplo de función cuadrática

def initialization(dim, Np, up, low):
    # Inicialización aleatoria uniforme
    return np.random.uniform(low, up, size=(Np, dim))

def test_functions_range(F_index, v):
    # Definición de límites y dimensión del problema (Placeholder)
    low = -10.0
    up = 10.0
    dim = 2
    return low, up, dim

def evolutionProcess(EP, MaxGeneration):
    # Calcula los límites de iteración para cada fase (IT)
    proportions = np.array(EP) / 100.0
    IT = np.cumsum(proportions * MaxGeneration)
    return IT

def centroide(totalOrdenado, clust):
    # Calcula el centroide de cada cluster
    max_clust = np.max(clust)
    centroids = np.zeros((max_clust, totalOrdenado.shape[1]))
    for k in range(1, max_clust + 1):
        points = totalOrdenado[clust == k]
        if points.size > 0:
            centroids[k-1, :] = np.mean(points, axis=0)
    return centroids

def clusterDensity(totalOrdenado, centroid, clust, aux_clust, dim):
    # Placeholder: Simulación de densidad (Reemplazar con lógica real)
    densities = np.random.rand(aux_clust) * 0.5 + 0.5 # Entre 0.5 y 1.0
    return densities

def chaosVector(X, low, up, dim, type):
    # Placeholder: Genera un vector caótico (Reemplazar con lógica real)
    if X.ndim == 1:
        return np.random.rand(dim)
    return np.random.rand(X.shape[-1])

def findrange(X, low, up, dim, type):
    # Aplica restricciones de límites (clamping)
    if isinstance(low, (float, int)) and isinstance(up, (float, int)):
        return np.clip(X, low, up)
    return np.clip(X, low, up)

def minim(totalOrdenado, F_index, fT, count):
    # Obtiene el mejor fitness de la población y lo retorna
    fitness = evaluateF(totalOrdenado, F_index)
    min_fit = np.min(fitness)
    # Nota: el código original de MATLAB solo retorna el mínimo, la actualización de fT
    # se gestiona en el bucle principal.
    return min_fit

def vTransform(dim, alfAdaptive):
    # Transformación vectorial
    return np.full(dim, alfAdaptive) * np.random.rand(dim)
# -----------------------------------------------------------------------------------

def COC_python(F_index, Np, MaxGeneration, typeC, v):
    """
    Función contenedora y bloque de inicialización
    """
    global contador
    fT = np.zeros(MaxGeneration + 2)
    low, up, dim = test_functions_range(F_index, v)
    
    # Cálculo de alfTotal
    if isinstance(up, (float, int)) and isinstance(low, (float, int)):
        alfTotal = (up - low)
    else:
        alfTotal = np.sum(up - low) / dim
        
    if isinstance(alfTotal, np.ndarray) or alfTotal > np.min(up):
        alfTotal = np.array(alfTotal) - np.array(up) # Asegurando operaciones vectoriales
        alfTotal = alfTotal / np.linalg.norm(alfTotal)
        
    EP = np.array([70, 20, 10])
    IT = evolutionProcess(EP, MaxGeneration)
    
    # Inicialización de la población
    X = initialization(dim, Np, up, low)
    fitness = evaluateF(X, F_index)
    
    Index = np.argsort(fitness)
    totalOrdenado = X[Index, :]
    Lightn = fitness[Index]
    
    xbest = totalOrdenado[0, :]
    fobj = Lightn[0]
    
    # Segunda evaluación (para fidelidad con el código original)
    fitness = evaluateF(totalOrdenado, F_index)
    IndexBest = np.argsort(fitness)
    totalOrdenado = totalOrdenado[IndexBest, :]
    LightnBest = fitness[IndexBest]
    fT[0] = LightnBest[0]
    
    count = 0
    phase = 1
    div = 100
    cutmean = 1.0 # Inicialización de cutmean

    # ----------------------------------------------------------------------
    ## CICLO PRINCIPAL
    # ----------------------------------------------------------------------
    
    while count <= MaxGeneration:
        
        # A. AJUSTE DE PARÁMETROS DE BÚSQUEDA
        # Usamos phase - 1 porque Python usa índices base 0
        alfAdaptive = alfTotal * (EP[phase - 1] / div)
        
        # B. AGRUPAMIENTO (CLUSTERING)
        Z = linkage(totalOrdenado, method='ward', metric='euclidean')
        I = inconsistent(Z)
        
        cutAux = cutmean # Guardar el valor anterior
        
        # Determinar el umbral de corte (basado en el 4to columna de inconsistente)
        if I.size > 0:
            cutmean = np.max(I[:, 3])
            cutmean = cutmean - (cutmean * 0.001)
        
        if cutmean <= 0 or not np.isfinite(cutmean):
            cutmean = cutAux

        # Asignación de clusters
        clust = fcluster(Z, cutmean, criterion='distance')
        aux_clust = np.max(clust)
        
        # Cálculo de Centroide y Densidad
        centroid = centroide(totalOrdenado, clust)
        density = clusterDensity(totalOrdenado, centroid, clust, aux_clust, dim)
        density = np.sort(density)
        
        bestCluster = np.zeros((aux_clust, dim))
        LightnBest_updated = LightnBest.copy() 
        
        # C. BÚSQUEDA Y REFINAMIENTO (POR CLUSTER)
        for k in range(1, aux_clust + 1):
            
            # 1. Determinar el mejor del cluster (B_k)
            # np.where devuelve una tupla de arrays; [0][0] es el primer índice
            f = np.where(clust == k)[0][0] 
            bestCluster[k - 1, :] = totalOrdenado[f, :]
            
            # 2. Actualizar INDIVIDUOS NO-MEJORES
            index = np.where(clust == k)[0]
            index = index[1:] # Saltar el mejor (índice 0)
            
            if index.size > 0:
                for i in index:
                    xAux = totalOrdenado[i, :]
                    
                    # Movimiento hacia B_k
                    totalOrdenado[i, :] = xAux + ((bestCluster[k - 1, :] - xAux) * chaosVector(totalOrdenado[i, :], low, up, dim, 3) * density[k - 1])
                    totalOrdenado[i, :] = findrange(totalOrdenado[i, :], low, up, dim, 1)
                    
                    # Evaluación (1 acceso)
                    fitnessO = evaluateF(totalOrdenado[i, :], F_index)[0]
                    LightnBest_updated[i] = fitnessO
                    fT[count + 1] = minim(totalOrdenado, F_index, fT, count)
                    count += 1
                    
                    # Refinamiento 3 (Left and Right)
                    vT = vTransform(dim, alfAdaptive)
                    left = totalOrdenado[i, :] - (totalOrdenado[i, :] * chaosVector(totalOrdenado[i, :], low, up, dim, 3)) * vT
                    left = findrange(left, low, up, dim, 1)
                    
                    vT = vTransform(dim, alfAdaptive)         
                    right = totalOrdenado[i, :] + (totalOrdenado[i, :] * chaosVector(totalOrdenado[i, :], low, up, dim, 3)) * vT
                    right = findrange(right, low, up, dim, 1)
                    
                    # Evaluación (2 accesos)
                    fitnessLR = evaluateF(np.vstack([left, right]), F_index)
                    fT[count + 1] = fT[count]
                    fT[count + 2] = fT[count]
                    count += 2
                    
                    # Elitismo local (reemplazo)
                    if fitnessLR[0] < fitnessO:
                        totalOrdenado[i, :] = left
                        LightnBest_updated[i] = fitnessLR[0]
                    
                    if fitnessLR[1] < LightnBest_updated[i]:
                        totalOrdenado[i, :] = right
                        LightnBest_updated[i] = fitnessLR[1]
                        
                    fT[count + 1] = minim(totalOrdenado, F_index, fT, count)
                    
            # 3. Actualizar MEJOR DEL CLUSTER (B_k)
            vT = vTransform(dim, alfAdaptive)
            
            # Movimiento hacia el mejor global (xbest)
            bestCluster[k - 1, :] = bestCluster[k - 1, :] + (xbest - bestCluster[k - 1, :]) * vT * (chaosVector(bestCluster[k - 1, :], low, up, dim, 12))  
            bestCluster[k - 1, :] = findrange(bestCluster[k - 1, :], low, up, dim, 1)
            
            # Evaluación (1 acceso)
            fitnessOBC = evaluateF(bestCluster[k - 1, :], F_index)[0]
            fT[count + 1] = minim(totalOrdenado, F_index, fT, count)
            count += 1
            
            totalOrdenado[f, :] = bestCluster[k - 1, :]
            LightnBest_updated[f] = fitnessOBC
            
            # Refinamiento (Left and Right)
            vT = vTransform(dim, alfAdaptive)
            left = bestCluster[k - 1, :] - (bestCluster[k - 1, :] * chaosVector(bestCluster[k - 1, :], low, up, dim, 12)) * vT
            left = findrange(left, low, up, dim, 1)
            
            vT = vTransform(dim, alfAdaptive)            
            right = bestCluster[k - 1, :] + (bestCluster[k - 1, :] * chaosVector(bestCluster[k - 1, :], low, up, dim, 12)) * vT
            right = findrange(right, low, up, dim, 1)
            
            # Evaluación (2 accesos)
            fitnessLR = evaluateF(np.vstack([left, right]), F_index)
            fT[count + 1] = fT[count]
            fT[count + 2] = fT[count]
            count += 2
            
            # Elitismo local (reemplazo)
            if fitnessLR[0] < fitnessOBC:
                totalOrdenado[f, :] = left
                LightnBest_updated[f] = fitnessLR[0]
            
            if fitnessLR[1] < LightnBest_updated[f]:
                totalOrdenado[f, :] = right
                LightnBest_updated[f] = fitnessLR[1]
            
            fT[count + 1] = minim(totalOrdenado, F_index, fT, count)
            
        # D. SELECCIÓN Y ELITISMO GLOBAL
        LightnBest = LightnBest_updated # Aplicar los fitness actualizados
        
        # Reordenamiento
        IndexBest = np.argsort(LightnBest)
        LightnBest = LightnBest[IndexBest]
        totalOrdenado = totalOrdenado[IndexBest, :]
        
        # Elitismo (actualización de la mejor solución global)
        if LightnBest[0] < fobj:
            xbest = totalOrdenado[0, :]
            fobj = LightnBest[0]
            
        # CONTROL DE FASE DE EVOLUCIÓN
        # Usamos phase - 1 porque IT es base 0
        if phase < len(IT) and count > IT[phase - 1]:
            phase += 1
            div *= MaxGeneration
            
    # Ajuste final de fT
    fT = fT[:count + 1]
    
    return xbest, fobj, totalOrdenado, fT, contador

# --- NOTA DE IMPLEMENTACIÓN ---
# Para ejecutar este código, debes asegurarte de que las funciones auxiliares 
# como 'evaluateF', 'chaosVector', 'vTransform', etc., contengan la lógica 
# adecuada para tu problema de optimización.