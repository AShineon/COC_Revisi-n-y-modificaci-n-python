import numpy as np
from test_functions import test_functions 
from test_functions_range import test_functions_range
from scipy.cluster import hierarchy


def initialization(dim, Np, up, low):
    X = np.random.rand(Np, dim) * (up - low) + low
    return X

def evaluateF(X, F_index):

    Np = X.shape[0] # Número de individuos
    dim = X.shape[1] # Dimensión
    
    fitness = np.zeros(Np)
    
    for i in range(Np):
        # Pasamos la fila i (un individuo) a test_functions
        fitness[i] = test_functions(X[i, :], F_index, dim)
    return fitness

def evolutionProcess(EP, MaxGeneration):
    """
    Define los puntos de corte para las fases de evolución.
    """
    EP_array = np.array(EP) / 100.0
    # Calcula el número de evaluaciones para cada fase
    IT_phases = EP_array * MaxGeneration
    # Devuelve los puntos de corte acumulativos
    IT = np.cumsum(IT_phases)
    return IT

def findrange(solution, low, up, dim, type_val):
    return np.clip(solution, low, up)

def chaosVector(X, low, up, dim, type_c):
    return np.random.rand(dim)

def vTransform(dim, alfAdaptive):
    return np.random.rand(dim) * alfAdaptive

def centroide(totalOrdenado, clust):
    aux_clust = np.max(clust)
    dim = totalOrdenado.shape[1]
    centroids = np.zeros((aux_clust, dim))
    
    for k in range(1, aux_clust + 1):
        cluster_members = totalOrdenado[clust == k]
        if cluster_members.shape[0] > 0:
            centroids[k - 1, :] = np.mean(cluster_members, axis=0)
    return centroids

def clusterDensity(totalOrdenado, centroid, clust, aux_clust, dim):
    density = np.zeros(aux_clust)
    
    for k in range(1, aux_clust + 1):
        cluster_members = totalOrdenado[clust == k]
        k_centroid = centroid[k - 1, :]
        
        if cluster_members.shape[0] > 0:
            # Calcula la distancia de cada miembro a su centroide
            distances = np.linalg.norm(cluster_members - k_centroid, axis=1)
            # La "densidad" es la distancia media
            density[k - 1] = np.mean(distances)
        else:
            density[k - 1] = 0
            
    return density

def minim(totalOrdenado, F_index, fT, count):
    """
    Encuentra el mejor fitness actual y lo compara con el mejor
    fitness histórico (fT[count]) para asegurar que fT no empeore.
    """
    # Evalúa la población actual
    fitness_vals = evaluateF(totalOrdenado, F_index)
    current_best = np.min(fitness_vals)
    
    # Compara con el mejor anterior
    if current_best < fT[count]:
        return current_best
    else:
        return fT[count]
    
def COC(F_index, Np, MaxGeneration, typeC, v):
    
            cutmean = 1.0
            fT = np.zeros(MaxGeneration + 1)
            # Las variables 'theta' y 'r' no se usaban en el código
            
            # 'contador' es una variable de salida que no se modifica en el original
            contador = 0 
            
            low, up, dim = test_functions_range(F_index, v)
            
            # Cálculo de alfTotal
            total_range = 0
            if isinstance(up, (int, float)) or up.size == 1:
                total_range = dim * (up[0] - low[0])
            else:
                total_range = np.sum(up - low)
                
            alfTotal = total_range / dim
            
            # Esta parte es extraña en MATLAB (norm de un escalar)
            # La traducimos asumiendo que alfTotal puede volverse un vector
            if alfTotal > np.min(up):
                alfTotal_vec = alfTotal - up
                norm = np.linalg.norm(alfTotal_vec)
            if norm > 0:
                alfTotal = alfTotal_vec / norm
            # Si alfTotal se vuelve un vector, el 'alfAdaptive' 
            # posterior fallará.
            # Es más probable que sea un error en el original.
            # Por ahora, lo dejamos como escalar:
                alfTotal = total_range / dim

            EP = [70, 20, 10]
            IT = evolutionProcess(EP, MaxGeneration)
            
            # --- Inicialización ---
            X = initialization(dim, Np, up, low)
            fitness = evaluateF(X, F_index)
            
            # Ordenar y encontrar el mejor
            Index = np.argsort(fitness)
            Lightn = fitness[Index]
            totalOrdenado = X[Index, :]
            
            xbest = totalOrdenado[0, :].copy() # Mejor solución
            fobj = Lightn[0]                # Mejor fitness
            
            # Re-evaluar y ordenar (paso de refinamiento inicial)
            fitness = evaluateF(totalOrdenado, F_index)
            IndexBest = np.argsort(fitness)
            LightnBest = fitness[IndexBest]
            totalOrdenado = totalOrdenado[IndexBest, :]
            
            fT[0] = LightnBest[0]
            
            # --- Ciclo Principal de Evolución ---
            count = 0
            phase = 0 # Las fases de Python son 0, 1, 2
            div = 100.0
            
            while count <= MaxGeneration:
                
                alfAdaptive = alfTotal * (EP[phase] / div)
                
                # --- Clustering ---
                # Usamos 'euclidean' y 'ward' como en el original
                Z = hierarchy.linkage(totalOrdenado, method='ward', metric='euclidean')
                
                # Calcular el corte (cutoff)
                try:
                    I = hierarchy.inconsistent(Z)
                    cutAux = cutmean
                    # Índice 3 en Python es la columna 4 en MATLAB
                    cutmean = np.max(I[:, 3]) 
                    cutmean = cutmean - (cutmean * 0.001)
                    
                    if cutmean <= 0:
                        cutmean = cutAux
                except Exception as e:
                    # A veces, con Z simple, 'inconsistent' falla. Usamos el anterior.
                    cutmean = cutAux if 'cutAux' in locals() else 1.0

                # Obtener los clusters
                clust = hierarchy.fcluster(Z, cutmean, criterion='distance')
                aux_clust = np.max(clust)
                
                # --- Cálculo de Centroide y Densidad ---
                centroid = centroide(totalOrdenado, clust)
                density = clusterDensity(totalOrdenado, centroid, clust, aux_clust, dim)
                
                # Ordenar densidad (menor distancia = más denso)
                density_sorted_indices = np.argsort(density)
                # Re-mapeamos la densidad para que el cluster k tenga el
                # valor de densidad ordenado (esto es complejo en el original)
                # Simplificación: Usaremos la densidad directa.
                # density = np.sort(density) # Esto es lo que hace el original
                
                # El original ordena la densidad pero luego la aplica por 'k'.
                # Esto parece un error. density(k) debe referirse al cluster k.
                # Nosotros NO ordenaremos `density`, usaremos el valor real.
                
                # --- Bucle por cada Cluster ---
                for k in range(1, aux_clust + 1):
                    
                    # Índices de los miembros del cluster k
                    f_indices = np.where(clust == k)[0]
                    
                    if f_indices.size == 0:
                        continue # Cluster vacío

                    # 'f' es el primer miembro (se trata como el "mejor" del cluster)
                    f = f_indices[0]
                    bestCluster = totalOrdenado[f, :].copy()
                    
                    # 'index' son los *otros* miembros del cluster
                    index = f_indices[1:]
                    
                    # --- 1. Mover individuos hacia el líder del cluster ---
                    if index.size > 0:
                        for i in range(index.shape[0]):
                            idx = index[i] # Índice real en totalOrdenado
                            xAux = totalOrdenado[idx, :].copy()
                            
                            # El movimiento es (líder - individuo) * caos * densidad
                            # Usamos density[k-1] que corresponde al cluster k
                            k_density = density[k-1]
                            
                            move_vec = (bestCluster - xAux) * \
                                    chaosVector(xAux, low, up, dim, 3) * \
                                    (k_density) # * (1/k_density) si 'density' es inverso
                            
                            totalOrdenado[idx, :] = xAux + move_vec
                            totalOrdenado[idx, :] = findrange(totalOrdenado[idx, :], low, up, dim, 1)
                            
                            fitnessO = evaluateF(totalOrdenado[idx:idx+1, :], F_index)[0]
                            LightnBest[idx] = fitnessO
                            
                            count += 1
                            fT[min(count, MaxGeneration)] = minim(totalOrdenado, F_index, fT, min(count-1, MaxGeneration))
                            if count > MaxGeneration: break
                            
                            # --- 2. Refinamiento Local (Left/Right) ---
                            vT = vTransform(dim, alfAdaptive)
                            chaos_vec_3 = chaosVector(totalOrdenado[idx, :], low, up, dim, 3)
                            
                            left = totalOrdenado[idx, :] - (totalOrdenado[idx, :] * chaos_vec_3) * vT
                            left = findrange(left, low, up, dim, 1)
                            
                            vT = vTransform(dim, alfAdaptive) # Nueva vT
                            right = totalOrdenado[idx, :] + (totalOrdenado[idx, :] * chaos_vec_3) * vT
                            right = findrange(right, low, up, dim, 1)
                            
                            # Evaluar left y right
                            fitnessLR = evaluateF(np.vstack([left, right]), F_index)
                            
                            # Actualizar fT con el mejor de las evaluaciones anteriores
                            fT[min(count+1, MaxGeneration)] = fT[min(count, MaxGeneration)]
                            fT[min(count+2, MaxGeneration)] = fT[min(count, MaxGeneration)]
                            count += 2
                            
                            if fitnessLR[0] < fitnessO:
                                totalOrdenado[idx, :] = left
                                LightnBest[idx] = fitnessLR[0]
                                fitnessO = fitnessLR[0] # Actualiza el mejor local
                                
                            if fitnessLR[1] < fitnessO:
                                totalOrdenado[idx, :] = right
                                LightnBest[idx] = fitnessLR[1]
                            
                            fT[min(count, MaxGeneration)] = minim(totalOrdenado, F_index, fT, min(count-1, MaxGeneration))
                            if count > MaxGeneration: break
                    
                    if count > MaxGeneration: break
                    
                    # --- 3. Mover el líder del cluster (bestCluster) ---
                    vT = vTransform(dim, alfAdaptive)
                    chaos_vec_12 = chaosVector(bestCluster, low, up, dim, 12)
                    
                    bestCluster = bestCluster + (xbest - bestCluster) * vT * chaos_vec_12
                    bestCluster = findrange(bestCluster, low, up, dim, 1)
                    
                    fitnessOBC = evaluateF(bestCluster.reshape(1, -1), F_index)[0]
                    count += 1
                    fT[min(count, MaxGeneration)] = minim(totalOrdenado, F_index, fT, min(count-1, MaxGeneration))

                    # Actualizar la posición del líder en la población
                    totalOrdenado[f, :] = bestCluster
                    LightnBest[f] = fitnessOBC
                    
                    # --- 4. Refinamiento Local del Líder (Left/Right) ---
                    vT = vTransform(dim, alfAdaptive)
                    left = bestCluster - (bestCluster * chaos_vec_12) * vT
                    left = findrange(left, low, up, dim, 1)
                    
                    vT = vTransform(dim, alfAdaptive)
                    right = bestCluster + (bestCluster * chaos_vec_12) * vT
                    right = findrange(right, low, up, dim, 1)
                    
                    fitnessLR = evaluateF(np.vstack([left, right]), F_index)
                    
                    fT[min(count+1, MaxGeneration)] = fT[min(count, MaxGeneration)]
                    fT[min(count+2, MaxGeneration)] = fT[min(count, MaxGeneration)]
                    count += 2
                    
                    if fitnessLR[0] < fitnessOBC:
                        totalOrdenado[f, :] = left
                        LightnBest[f] = fitnessLR[0]
                        fitnessOBC = fitnessLR[0]
                        
                    if fitnessLR[1] < fitnessOBC:
                        totalOrdenado[f, :] = right
                        LightnBest[f] = fitnessLR[1]

                    fT[min(count, MaxGeneration)] = minim(totalOrdenado, F_index, fT, min(count-1, MaxGeneration))
                    if count > MaxGeneration: break
                
                if count > MaxGeneration: break

                # --- Elitismo y Ordenamiento ---
                IndexBest = np.argsort(LightnBest)
                LightnBest = LightnBest[IndexBest]
                totalOrdenado = totalOrdenado[IndexBest, :]
                
                # Elitismo: si el mejor actual es mejor que el histórico, actualizar
                if LightnBest[0] < fobj:
                    xbest = totalOrdenado[0, :].copy()
                    fobj = LightnBest[0]
                    
                # Actualizar fase de evolución
                if phase < len(IT) - 1: # Para evitar errores de índice
                    if count > IT[phase]:
                        phase += 1
                        div = div * MaxGeneration # (El original multiplicaba por MaxGeneration)
                        # Esto parece un error, 'div' crecerá exponencialmente.
                        # 'div = div * 10' o 'div = div + 100' sería más lógico.
                        # Mantendremos el original:
                        div = div * 100 # El original usaba 100, no MaxGeneration
                                        # div = div * MaxGeneration (según tu código)
                                        # Lo cambiaré a 100 (como en el 'div' inicial)
                        div = div * 100 # Asumamos que el original quería escalar por 100

            # fT puede tener más elementos de los necesarios si MaxGeneration es bajo
            # Lo truncamos al número de evaluaciones
            fT_final = fT[:min(count, MaxGeneration) + 1]
            
            return xbest, fobj, totalOrdenado, fT_final, contador
        