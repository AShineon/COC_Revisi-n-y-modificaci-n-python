import numpy as np
from COC_PythonVersion_v2 import COC 


F_index = 3          
Np = 70              
MaxGeneration = 100   
typeC = 1            
v = 1                
 
num_ejecuciones = 2000
total_fitness = 0.0

print(f"Iniciando simulación de {num_ejecuciones} ejecuciones del algoritmo COC.")
print(f"Función: F_index = {F_index} (Rastrigin), Población (Np): {Np}, Generaciones: {MaxGeneration}")
print("-" * 50)

for i in range(num_ejecuciones):
    xbest, fobj, final_population, fT_history, num_evaluations = \
    COC(F_index, Np, MaxGeneration, typeC, v)
    
    total_fitness += fobj
    
    if (i + 1) % 100 == 0:
        print(f"Completadas {i + 1} de {num_ejecuciones} ejecuciones. Fitness acumulado: {total_fitness:.4f}")

promedio_fitness = total_fitness / num_ejecuciones

print("-" * 50)
print(f"✅ Simulación completada.")
print(f"Número total de ejecuciones: {num_ejecuciones}")
print(f"Suma de los mejores fitness (fobj): {total_fitness:.6f}")
print(f"Promedio del mejor fitness (fobj) en {num_ejecuciones} ejecuciones: {promedio_fitness:.6f}")

print("\n✅ Algoritmo Terminado.")
print("--- Resultados Finales ---")
print(f"Evaluaciones Totales Realizadas: {len(fT_history) - 1}")
print(f"Mejor Fitness Encontrado (fobj): {fobj:}")
print(f"Vector de la Mejor Solución (xbest):")
print(xbest[:5])
if xbest.size > 5:
    print("... (más dimensiones)")

print(f"\nLongitud del Histórico de Mejor Fitness (fT_final): {len(fT_history)}")
