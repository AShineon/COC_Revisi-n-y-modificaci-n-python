import numpy as np
from scipy.cluster import hierarchy

def test_functions(L, F_index, dim):
    # Definimos 'up' aquí solo para F_index 1
    # Sería mejor pasarlo como parámetro.
    up_val = 100 
    A = 10  # Constante para Rastrigin
    
    fit = 0
    if F_index == 1:  # Sphere (con traslación)
        # Replicamos L = up - L
        L_shifted = up_val - L
        fit = np.sum(L_shifted**2)
    elif F_index == 2: # Rastrigin (Multimodal)
        # La forma estándar para Rastrigin
        term1 = np.sum(L**2)
        term2 = np.sum(A * np.cos(2 * np.pi * L))
        fit = A * dim + term1 - term2
    elif F_index == 3: # Hybrid Simplificada (Sphere + Rastrigin)
        # Dividimos el vector L en dos subcomponentes (simplificación)
        mid_point = dim // 2
        L1 = L[:mid_point]  # Componente unimodal (Sphere)
        L2 = L[mid_point:] # Componente multimodal (Rastrigin)
        
        fit1 = np.sum(L1**2)
        dim2 = L2.size
        term1_rast = np.sum(L2**2)
        term2_rast = np.sum(A * np.cos(2 * np.pi * L2))
        fit2 = A * dim2 + term1_rast - term2_rast
        # El fitness total es la suma de los componentes
        fit = fit1 + fit2
    return fit
