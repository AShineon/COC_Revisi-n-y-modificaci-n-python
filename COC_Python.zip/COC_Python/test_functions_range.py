import numpy as np
from scipy.cluster import hierarchy

def test_functions_range(F_index, v):
    """
    Define los límites y la dimensión para la función de prueba.
    'v' no se usa en el código original para esta parte, pero lo mantenemos.
    """
    dim = 1  # Definimos una dimensión estándar, ej. 10
    low = -100
    up = 100
    
    if F_index == 1: # Sphere
        low = -100
        up = 100
        dim = 2
    elif F_index == 2: # Rastrigin
        low = -5.12
        up = 5.12
        dim = 2
    elif F_index == 26: # Hybrid Function 1 (Rotated)
        low = -100
        up = 100
        dim = 2
    # Si 'low' y 'up' son escalares, los convertimos en arrays
    if not isinstance(low, (np.ndarray, list)):
        low = np.full(dim, low)
    if not isinstance(up, (np.ndarray, list)):
        up = np.full(dim, up)
    return low, up, dim